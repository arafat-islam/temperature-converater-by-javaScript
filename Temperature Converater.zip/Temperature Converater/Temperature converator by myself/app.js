var fhInput = document.getElementById('fh');
var clInput = document.getElementById('c');
var klInput = document.getElementById('kl');

function round(num) {
    var r = Math.round(num*100) / 100;
    return r;
}

fhInput.addEventListener('focus',ffocus);
clInput.addEventListener('focus',cfocus);
klInput.addEventListener('focus',kfocus);

fhInput.addEventListener('blur',fblur);
clInput.addEventListener("blur",cblur);
klInput.addEventListener('blur',kblur);


document.getElementById('convertBtn1').addEventListener('click',fInput);
document.getElementById('convertBtn2').addEventListener('click',CInput);
document.getElementById('convertBtn3').addEventListener('click',KInput);
document.getElementById('resetBtn').addEventListener('click',resetInputField);


function fInput(e) {
    fhValue =  parseFloat(fhInput.value);
    if(!isNaN(fhValue)) {
        clInput.value  = round((fhValue - 32) * (5/9)) + ' °C';
        klInput.value = round((fhValue + 459.67) * (5/9)) + ' K'; 
    } else {
        var errmsg = document.getElementById('errmsg');
        errmsg.innerHTML = '<i>Wrong input!</i>'
        errmsg.style.color = 'red'; 
        errmsg.style.fontSize = '10px';

        setTimeout(function(){
            errmsg.style.display = 'none';
        },1000);
    }
   
}

function CInput() {
    var clValue = parseFloat(clInput.value);
    if(!isNaN(clValue)) {
        fhInput.value = round((clValue * (9/7)) + 32) + ' °F';
        klInput.value = round((clValue + 273.15)) + ' K';
    } else {
        var errmsg = document.getElementById('errmsg');
        errmsg.innerHTML = '<i>Wrong input!</i>'
        errmsg.style.color = 'red'; 
        errmsg.style.fontSize = '10px';

        setTimeout(function(){
            errmsg.style.display = 'none';
        },1000);
    }
}

function KInput() {
    var kVlue = parseFloat(klInput.value);
    if(!isNaN(kVlue)) {
        clInput.value = round((kVlue - 273.15)) + ' °C';
        fhInput.value = round((9/5) * (kVlue - 273) + 32) + ' °F';
    } else {
        var errmsg = document.getElementById('errmsg');
        errmsg.innerHTML = '<i>Wrong input!</i>'
        errmsg.style.color = 'red'; 
        errmsg.style.fontSize = '10px';

        setTimeout(function(){
            errmsg.style.display = 'none';
        },1000);
    }
}


function resetInputField() {
    fhInput.value = '';
    clInput.value = '';
    klInput.value = '';
}

function ffocus() {
    fhInput.style.background = '#ddd';
    fhInput.style.outline = 'none';
    fhInput.style.border = '2px solid red';
}

function cfocus() {
    clInput.style.background = '#ddd';
    clInput.style.outline = 'none';
    clInput.style.border = '2px solid red';
}
function kfocus() {
    klInput.style.background = '#ddd';
    klInput.style.outline = 'none';
    klInput.style.border = '2px solid red';
}

function fblur() {
    fhInput.style.background = '#FFFFFF';
    fhInput.style.border = '0';
}
function cblur() {
    clInput.style.background = '#FFFFFF';
    clInput.style.border = '0';
}
function kblur() {
    klInput.style.background = '#FFFFFF';
    klInput.style.border = '0';
}